# AWG-IUT
Front-end section of AWG website project
# updates :
هنوز فایل کامل نیست.
اسکلت صفحه home ساخته شده ولی بازم هنوز کامل نیست.
استایل های مربوط به navigation bar داده شده.
بخاطر نبود مدیا های حیاطی مثل : لوگو وبسایت، بنر صفحه home و ... پلت رنگی وبسایت مشخص نیست و من و بچه ها در سردرگمی کامل به سر می‌بریم.
# website description:
still nothing :)
